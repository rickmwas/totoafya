const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

/**
 * Checks if the current user has completed onboarding (has a Mother profile).
 * If not, redirects them to /onboarding.
 * Returns { mother, loading } for use in page components.
 */
export function useRequireOnboarding() {
  const navigate = useNavigate();
  const [mother, setMother] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    db.entities.Mother.list('-created_date', 1).then((mothers) => {
      if (!mothers || mothers.length === 0) {
        navigate('/onboarding', { replace: true });
      } else {
        setMother(mothers[0]);
      }
      setLoading(false);
    });
  }, []);

  return { mother, loading };
}